# payment_mercadopago
This implementation is for Odoo 14.0 Chile
