# -*- coding: utf-8 -*-

from . import mercadopago
#from . import res_company
