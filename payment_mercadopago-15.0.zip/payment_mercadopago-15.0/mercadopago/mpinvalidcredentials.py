from .mpexception import MPException

class MPInvalidCredentials(MPException):
    pass